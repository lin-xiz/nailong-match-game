(() => {
  "use strict";

  const DATA = window.GAME_DATA;
  if (!DATA) {
    throw new Error("关卡数据加载失败：请确认 data/levels.js 位于游戏目录中。");
  }

  const BOARD = DATA.board;
  const TILE_SIZE = BOARD.tileSize;
  const TRAY_SIZE = DATA.traySize;
  const STORAGE_KEY = "nailong-match-profile-v1";
  const BLOCK_OVERLAP_X = TILE_SIZE * 0.78;
  const BLOCK_OVERLAP_Y = TILE_SIZE * 0.78;

  const screens = {
    loading: document.getElementById("loading-screen"),
    menu: document.getElementById("menu-screen"),
    levels: document.getElementById("levels-screen"),
    game: document.getElementById("game-screen"),
  };

  const elements = {
    loadingBar: document.getElementById("loading-progress-bar"),
    loadingPercent: document.getElementById("loading-percent"),
    startButton: document.getElementById("start-button"),
    rankingButton: document.getElementById("ranking-button"),
    settingsButton: document.getElementById("settings-button"),
    dressupButton: document.getElementById("dressup-button"),
    levelsBackButton: document.getElementById("levels-back-button"),
    levelsSettingsButton: document.getElementById("levels-settings-button"),
    levelCount: document.getElementById("level-count"),
    levelGrid: document.getElementById("level-grid"),
    gameBackButton: document.getElementById("game-back-button"),
    gameLevelNumber: document.getElementById("game-level-number"),
    gameLevelName: document.getElementById("game-level-name"),
    scoreValue: document.getElementById("score-value"),
    roundProgressBar: document.getElementById("round-progress-bar"),
    boardWrap: document.getElementById("board-wrap"),
    boardStage: document.getElementById("board-stage"),
    floatingScoreLayer: document.getElementById("floating-score-layer"),
    comboBadge: document.getElementById("combo-badge"),
    tray: document.getElementById("tray"),
    undoButton: document.getElementById("undo-button"),
    shuffleButton: document.getElementById("shuffle-button"),
    returnButton: document.getElementById("return-button"),
    hintButton: document.getElementById("hint-button"),
    undoCount: document.getElementById("undo-count"),
    shuffleCount: document.getElementById("shuffle-count"),
    returnCount: document.getElementById("return-count"),
    hintCount: document.getElementById("hint-count"),
    modalLayer: document.getElementById("modal-layer"),
    settingsModal: document.querySelector('[data-modal="settings"]'),
    rankingModal: document.querySelector('[data-modal="ranking"]'),
    dressupModal: document.querySelector('[data-modal="dressup"]'),
    resultModal: document.querySelector('[data-modal="result"]'),
    soundToggle: document.getElementById("sound-toggle"),
    hapticsToggle: document.getElementById("haptics-toggle"),
    resetProgressButton: document.getElementById("reset-progress-button"),
    rankingList: document.getElementById("ranking-list"),
    resultCharacter: document.getElementById("result-character"),
    resultKicker: document.getElementById("result-kicker"),
    resultTitle: document.getElementById("result-title"),
    resultScoreValue: document.getElementById("result-score-value"),
    resultSecondaryButton: document.getElementById("result-secondary-button"),
    resultPrimaryButton: document.getElementById("result-primary-button"),
    toast: document.getElementById("toast"),
    themeColor: document.querySelector('meta[name="theme-color"]'),
  };

  const defaultProfile = {
    unlocked: 1,
    completed: [],
    scores: {},
    theme: "meadow",
    settings: {
      sound: true,
      haptics: true,
    },
  };

  function cloneProfile() {
    return JSON.parse(JSON.stringify(defaultProfile));
  }

  let profile = loadProfile();
  let currentScreen = "loading";
  let game = null;
  let actionLock = false;
  let toastTimer = null;
  let lastResult = null;

  class AudioKit {
    constructor() {
      this.context = null;
    }

    enabled() {
      return profile.settings.sound;
    }

    getContext() {
      if (!this.context) {
        const AudioContext = window.AudioContext || window.webkitAudioContext;
        if (!AudioContext) {
          return null;
        }
        this.context = new AudioContext();
      }
      if (this.context.state === "suspended") {
        this.context.resume().catch(() => {});
      }
      return this.context;
    }

    tone(frequency, start, duration, type = "sine", volume = 0.05) {
      const context = this.getContext();
      if (!context) {
        return;
      }
      const oscillator = context.createOscillator();
      const gain = context.createGain();
      oscillator.type = type;
      oscillator.frequency.setValueAtTime(frequency, context.currentTime + start);
      gain.gain.setValueAtTime(0.0001, context.currentTime + start);
      gain.gain.exponentialRampToValueAtTime(volume, context.currentTime + start + 0.012);
      gain.gain.exponentialRampToValueAtTime(
        0.0001,
        context.currentTime + start + duration,
      );
      oscillator.connect(gain);
      gain.connect(context.destination);
      oscillator.start(context.currentTime + start);
      oscillator.stop(context.currentTime + start + duration + 0.03);
    }

    play(name) {
      if (!this.enabled()) {
        return;
      }
      switch (name) {
        case "pick":
          this.tone(440, 0, 0.08, "sine", 0.035);
          break;
        case "match":
          this.tone(660, 0, 0.12, "triangle", 0.045);
          this.tone(880, 0.09, 0.16, "triangle", 0.04);
          break;
        case "deny":
          this.tone(150, 0, 0.12, "square", 0.025);
          break;
        case "power":
          this.tone(520, 0, 0.08, "triangle", 0.035);
          this.tone(760, 0.07, 0.12, "triangle", 0.03);
          break;
        case "win":
          this.tone(523, 0, 0.16, "triangle", 0.045);
          this.tone(659, 0.14, 0.18, "triangle", 0.045);
          this.tone(784, 0.3, 0.28, "triangle", 0.05);
          break;
        case "lose":
          this.tone(330, 0, 0.16, "sine", 0.04);
          this.tone(245, 0.14, 0.25, "sine", 0.04);
          break;
        default:
          break;
      }
    }
  }

  const audio = new AudioKit();

  function loadProfile() {
    try {
      const parsed = JSON.parse(localStorage.getItem(STORAGE_KEY) || "null");
      if (!parsed || typeof parsed !== "object") {
        return cloneProfile();
      }
      return {
        ...cloneProfile(),
        ...parsed,
        completed: Array.isArray(parsed.completed) ? parsed.completed : [],
        scores: parsed.scores && typeof parsed.scores === "object" ? parsed.scores : {},
        settings: {
          ...defaultProfile.settings,
          ...(parsed.settings || {}),
        },
      };
    } catch {
      return cloneProfile();
    }
  }

  function saveProfile() {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(profile));
    } catch {
      // Some browsers disable localStorage for file:// pages.
    }
  }

  function sleep(ms) {
    return new Promise((resolve) => window.setTimeout(resolve, ms));
  }

  function clamp(value, minimum, maximum) {
    return Math.min(maximum, Math.max(minimum, value));
  }

  function randomItem(items) {
    return items[Math.floor(Math.random() * items.length)];
  }

  function shuffle(items) {
    for (let index = items.length - 1; index > 0; index -= 1) {
      const swapIndex = Math.floor(Math.random() * (index + 1));
      [items[index], items[swapIndex]] = [items[swapIndex], items[index]];
    }
    return items;
  }

  function vibrate(pattern) {
    if (profile.settings.haptics && navigator.vibrate) {
      navigator.vibrate(pattern);
    }
  }

  function showToast(message, duration = 1800) {
    window.clearTimeout(toastTimer);
    elements.toast.textContent = message;
    elements.toast.classList.add("is-visible");
    toastTimer = window.setTimeout(() => {
      elements.toast.classList.remove("is-visible");
    }, duration);
  }

  function showScreen(name) {
    Object.entries(screens).forEach(([screenName, screen]) => {
      screen.classList.toggle("is-active", screenName === name);
    });
    currentScreen = name;
    if (name === "game") {
      window.requestAnimationFrame(fitBoard);
    }
  }

  function fitBoard() {
    if (!game || currentScreen !== "game") {
      return;
    }
    const width = elements.boardWrap.clientWidth;
    const height = elements.boardWrap.clientHeight;
    if (!width || !height) {
      return;
    }
    const scale = Math.min(width / BOARD.width, height / BOARD.height);
    elements.boardStage.style.setProperty("--board-scale", String(scale));
  }

  function preloadAssets(onProgress) {
    const sources = [
      ...DATA.characters.map((character) => character.image),
      "assets/characters/nailong-hero.png",
    ];
    const uniqueSources = [...new Set(sources)];
    let completed = 0;

    return Promise.all(
      uniqueSources.map(
        (source) =>
          new Promise((resolve) => {
            const image = new Image();
            const finish = () => {
              completed += 1;
              onProgress(completed / uniqueSources.length);
              resolve();
            };
            image.onload = finish;
            image.onerror = finish;
            image.src = source;
          }),
      ),
    );
  }

  function applyTheme(theme) {
    const supported = new Set(["meadow", "sunset", "candy"]);
    const nextTheme = supported.has(theme) ? theme : "meadow";
    profile.theme = nextTheme;
    document.body.dataset.theme = nextTheme;
    const themeColors = {
      meadow: "#a9df67",
      sunset: "#ffc777",
      candy: "#c6d4ff",
    };
    elements.themeColor.setAttribute("content", themeColors[nextTheme]);
    document.querySelectorAll("[data-theme-choice]").forEach((button) => {
      button.classList.toggle("is-active", button.dataset.themeChoice === nextTheme);
    });
    saveProfile();
  }

  function getLevel(levelId) {
    return DATA.levels.find((level) => level.id === Number(levelId));
  }

  function getCharacter(characterId) {
    return DATA.characters.find((character) => character.id === characterId);
  }

  function renderLevels() {
    elements.levelCount.textContent = String(DATA.levels.length);
    elements.levelGrid.replaceChildren();

    DATA.levels.forEach((level, index) => {
      const locked = level.id > profile.unlocked;
      const isComplete = profile.completed.includes(level.id);
      const character =
        DATA.characters[(level.id - 1 + Math.floor(index / 3)) % DATA.characters.length];
      const button = document.createElement("button");
      button.type = "button";
      button.className = "level-button";
      button.classList.toggle("is-locked", locked);
      button.classList.toggle("is-complete", isComplete);
      button.disabled = locked;
      button.style.setProperty("--level-accent", character.accent);
      button.setAttribute(
        "aria-label",
        locked
          ? `第 ${level.id} 关，尚未解锁`
          : `第 ${level.id} 关，${level.name}`,
      );
      button.innerHTML = `
        ${isComplete ? '<span class="level-badge" aria-label="已完成">✓</span>' : ""}
        <strong>第 ${level.id} 关</strong>
        <span>${level.name}<br>${level.subtitle}</span>
      `;
      button.addEventListener("click", () => startLevel(level.id));
      elements.levelGrid.append(button);
    });
  }

  function buildTypeDeck(groupCount) {
    const deck = [];
    for (let index = 0; index < groupCount; index += 1) {
      deck.push(DATA.characters[index % DATA.characters.length].id);
    }
    return shuffle(deck);
  }

  function patternAllows(normalizedX, normalizedY, pattern) {
    if (pattern === "diamond") {
      return normalizedX + normalizedY <= 2.01;
    }
    return true;
  }

  function buildCandidates(layout) {
    const layerCandidates = [];
    const padding = 28;

    for (let layer = 0; layer < layout.layers; layer += 1) {
      const shrink = Math.floor(layer / 2);
      const rows = Math.max(2, layout.rows - shrink);
      const cols = Math.max(2, layout.cols - shrink);
      const availableWidth = BOARD.width - padding * 2 - TILE_SIZE;
      const availableHeight = BOARD.height - padding * 2 - TILE_SIZE;
      const stepX = Math.min(92, availableWidth / Math.max(1, cols - 1));
      const stepY = Math.min(92, availableHeight / Math.max(1, rows - 1));
      const totalWidth = (cols - 1) * stepX + TILE_SIZE;
      const totalHeight = (rows - 1) * stepY + TILE_SIZE;
      const originX = (BOARD.width - totalWidth) / 2;
      const originY = (BOARD.height - totalHeight) / 2;
      const candidates = [];

      for (let row = 0; row < rows; row += 1) {
        for (let column = 0; column < cols; column += 1) {
          const normalizedX =
            cols <= 1 ? 0 : Math.abs(column - (cols - 1) / 2) / ((cols - 1) / 2);
          const normalizedY =
            rows <= 1 ? 0 : Math.abs(row - (rows - 1) / 2) / ((rows - 1) / 2);
          if (!patternAllows(normalizedX, normalizedY, layout.pattern)) {
            continue;
          }
          const staggerX = row % 2 === 1 ? stepX * 0.13 : 0;
          const staggerY = layer % 2 === 1 ? stepY * 0.08 : 0;
          const x = clamp(
            originX + column * stepX + staggerX + layer * 2,
            10,
            BOARD.width - TILE_SIZE - 10,
          );
          const y = clamp(
            originY + row * stepY + staggerY + layer * 3,
            10,
            BOARD.height - TILE_SIZE - 10,
          );
          candidates.push({ x, y, z: layer });
        }
      }
      layerCandidates.push(shuffle(candidates));
    }
    return layerCandidates;
  }

  function allocateLayerTargets(total, candidatesByLayer) {
    const weights = candidatesByLayer.map((_candidates, layer) =>
      Math.max(0.38, 1 - layer * 0.19),
    );
    const counts = candidatesByLayer.map(() => 0);
    let remaining = total;

    while (remaining > 0) {
      let selected = -1;
      let bestScore = -Infinity;
      for (let index = 0; index < candidatesByLayer.length; index += 1) {
        if (counts[index] >= candidatesByLayer[index].length) {
          continue;
        }
        const score = weights[index] / (counts[index] + 1);
        if (score > bestScore) {
          bestScore = score;
          selected = index;
        }
      }
      if (selected === -1) {
        break;
      }
      counts[selected] += 1;
      remaining -= 1;
    }

    return { counts, remaining };
  }

  function createPositions(level) {
    const target = level.groups * 3;
    const candidatesByLayer = buildCandidates(level.layout);
    const { counts, remaining } = allocateLayerTargets(target, candidatesByLayer);
    if (remaining > 0) {
      throw new Error(`第 ${level.id} 关位置不足，缺少 ${remaining} 个位置。`);
    }

    const selected = [];
    candidatesByLayer.forEach((candidates, layer) => {
      selected.push(...candidates.slice(0, counts[layer]));
    });

    return selected
      .sort((first, second) => first.z - second.z || first.y - second.y || first.x - second.x)
      .map((position, index) => ({
        id: `tile-${level.id}-${index}-${Math.random().toString(36).slice(2, 7)}`,
        typeId: null,
        status: "board",
        x: position.x,
        y: position.y,
        z: position.z,
      }));
  }

  function boxesOverlap(first, second) {
    return (
      Math.abs(first.x - second.x) < BLOCK_OVERLAP_X &&
      Math.abs(first.y - second.y) < BLOCK_OVERLAP_Y
    );
  }

  function isCoveredWithin(tile, remainingIds, tileLookup) {
    for (const otherId of remainingIds) {
      const other = tileLookup.get(otherId);
      if (!other || other.z <= tile.z) {
        continue;
      }
      if (boxesOverlap(tile, other)) {
        return true;
      }
    }
    return false;
  }

  function assignTypes(tiles, typeDeck, tray = []) {
    const boardTiles = tiles.filter((tile) => tile.status === "board");
    const boardLookup = new Map(boardTiles.map((tile) => [tile.id, tile]));
    const deficits = new Map();

    typeDeck.forEach((typeId) => {
      deficits.set(typeId, (deficits.get(typeId) || 0) + 3);
    });
    tray.forEach((tileId) => {
      const trayTile = tiles.find((tile) => tile.id === tileId);
      if (trayTile) {
        deficits.set(trayTile.typeId, (deficits.get(trayTile.typeId) || 0) - 1);
      }
    });

    const activeGroups = shuffle(
      [...deficits.entries()]
        .filter(([, count]) => count > 0)
        .map(([typeId]) => typeId),
    );
    const remainingIds = new Set(boardTiles.map((tile) => tile.id));

    boardTiles.forEach((tile) => {
      tile.typeId = null;
    });

    for (const typeId of activeGroups) {
      const needed = deficits.get(typeId) || 0;
      for (let index = 0; index < needed; index += 1) {
        const available = [];
        for (const tileId of remainingIds) {
          const tile = boardLookup.get(tileId);
          if (!isCoveredWithin(tile, remainingIds, boardLookup)) {
            available.push(tile);
          }
        }
        if (available.length === 0) {
          return false;
        }

        available.sort((first, second) => {
          const scoreFirst = first.z * 6 - first.y * 0.08 + Math.random() * 3;
          const scoreSecond = second.z * 6 - second.y * 0.08 + Math.random() * 3;
          return scoreSecond - scoreFirst;
        });
        const selected = available[Math.min(available.length - 1, Math.floor(Math.random() * 3))];
        selected.typeId = typeId;
        remainingIds.delete(selected.id);
      }
    }

    return remainingIds.size === 0;
  }

  function createAssignedTiles(level) {
    const typeDeck = buildTypeDeck(level.groups);
    let lastError = null;

    for (let attempt = 0; attempt < 80; attempt += 1) {
      const tiles = createPositions(level);
      if (assignTypes(tiles, typeDeck)) {
        return { tiles, typeDeck };
      }
      lastError = new Error("当前布局无法生成可解牌序");
    }
    throw lastError || new Error("无法创建关卡");
  }

  function createTileElement(tile) {
    const character = getCharacter(tile.typeId);
    const button = document.createElement("button");
    button.type = "button";
    button.className = "tile";
    button.dataset.tileId = tile.id;
    button.style.setProperty("--accent", character.accent);
    button.style.left = `${tile.x}px`;
    button.style.top = `${tile.y}px`;
    button.style.setProperty("--z", String(100 + tile.z * 100));
    button.setAttribute("aria-label", character.name);
    button.innerHTML = `
      <span class="tile__face">
        <img src="${character.image}" alt="" draggable="false">
      </span>
    `;
    button.addEventListener("click", () => takeTile(tile.id));
    return button;
  }

  function startLevel(levelId) {
    const level = getLevel(levelId);
    if (!level || level.id > profile.unlocked) {
      return;
    }

    try {
      const { tiles, typeDeck } = createAssignedTiles(level);
      game = {
        level,
        typeDeck,
        tiles,
        tray: [],
        score: 0,
        combo: 0,
        moveCount: 0,
        history: [],
        over: false,
        powers: {
          undo: level.undo,
          shuffle: level.shuffle,
          returnThree: level.returnThree,
          hint: 3,
        },
      };

      elements.boardStage.replaceChildren(elements.floatingScoreLayer);
      tiles.forEach((tile) => {
        tile.element = createTileElement(tile);
        elements.boardStage.append(tile.element);
      });

      elements.gameLevelNumber.textContent = `第 ${level.id} 关`;
      elements.gameLevelName.textContent = level.name;
      closeModal();
      showScreen("game");
      renderGame();
      window.setTimeout(fitBoard, 0);
    } catch (error) {
      showToast(error.message || "关卡创建失败");
      console.error(error);
    }
  }

  function snapshotGame() {
    return {
      tiles: game.tiles.map((tile) => ({
        id: tile.id,
        typeId: tile.typeId,
        status: tile.status,
        x: tile.x,
        y: tile.y,
        z: tile.z,
      })),
      tray: [...game.tray],
      score: game.score,
      combo: game.combo,
      moveCount: game.moveCount,
    };
  }

  function pushHistory() {
    game.history.push(snapshotGame());
    if (game.history.length > 36) {
      game.history.shift();
    }
  }

  function restoreSnapshot(snapshot) {
    const lookup = new Map(snapshot.tiles.map((tile) => [tile.id, tile]));
    game.tiles.forEach((tile) => {
      const saved = lookup.get(tile.id);
      if (!saved) {
        return;
      }
      tile.typeId = saved.typeId;
      tile.status = saved.status;
      tile.x = saved.x;
      tile.y = saved.y;
      tile.z = saved.z;
      const character = getCharacter(tile.typeId);
      if (character && tile.element) {
        tile.element.style.setProperty("--accent", character.accent);
        tile.element.setAttribute("aria-label", character.name);
        const image = tile.element.querySelector("img");
        if (image) {
          image.src = character.image;
        }
      }
    });
    game.tray = [...snapshot.tray];
    game.score = snapshot.score;
    game.combo = snapshot.combo;
    game.moveCount = snapshot.moveCount;
    game.over = false;
  }

  function isCovered(tileId) {
    const tile = game.tiles.find((candidate) => candidate.id === tileId);
    if (!tile) {
      return true;
    }
    return game.tiles.some(
      (other) =>
        other.status === "board" &&
        other.z > tile.z &&
        boxesOverlap(tile, other),
    );
  }

  async function takeTile(tileId) {
    if (!game || game.over || actionLock || currentScreen !== "game") {
      return;
    }

    const tile = game.tiles.find((candidate) => candidate.id === tileId);
    if (!tile || tile.status !== "board") {
      return;
    }

    if (isCovered(tileId)) {
      tile.element.classList.remove("is-denied");
      void tile.element.offsetWidth;
      tile.element.classList.add("is-denied");
      audio.play("deny");
      vibrate(25);
      window.setTimeout(() => tile.element?.classList.remove("is-denied"), 280);
      return;
    }

    actionLock = true;
    pushHistory();
    tile.status = "tray";
    tile.element.classList.add("is-taken");
    game.tray.push(tile.id);
    game.score += 5;
    game.moveCount += 1;
    game.combo = 0;
    audio.play("pick");
    vibrate(8);
    renderGame();
    await sleep(120);

    const matched = findMatch();
    if (matched) {
      await clearMatch(matched);
    }

    if (!game.over) {
      if (game.tiles.every((candidate) => candidate.status === "removed") && game.tray.length === 0) {
        finishLevel(true);
      } else if (game.tray.length >= TRAY_SIZE) {
        finishLevel(false);
      }
    }

    actionLock = false;
  }

  function findMatch() {
    const groups = new Map();
    game.tray.forEach((tileId) => {
      const tile = game.tiles.find((candidate) => candidate.id === tileId);
      if (!tile) {
        return;
      }
      if (!groups.has(tile.typeId)) {
        groups.set(tile.typeId, []);
      }
      groups.get(tile.typeId).push(tile.id);
    });

    for (const ids of groups.values()) {
      if (ids.length >= 3) {
        return ids.slice(0, 3);
      }
    }
    return null;
  }

  async function clearMatch(tileIds) {
    game.combo += 1;
    const gain = 100 * Math.min(game.combo, 4);
    game.score += gain;
    audio.play("match");
    vibrate([18, 30, 25]);
    showCombo(gain, game.combo);

    tileIds.forEach((tileId) => {
      const tile = game.tiles.find((candidate) => candidate.id === tileId);
      if (tile?.element) {
        tile.element.classList.add("is-removing");
      }
    });
    await sleep(190);

    tileIds.forEach((tileId) => {
      const tile = game.tiles.find((candidate) => candidate.id === tileId);
      if (tile) {
        tile.status = "removed";
      }
    });
    game.tray = game.tray.filter((tileId) => !tileIds.includes(tileId));
    renderGame();
    await sleep(120);
  }

  function showCombo(gain, combo) {
    elements.comboBadge.textContent = combo > 1 ? `+${gain} 连消 x${combo}` : `+${gain}`;
    elements.comboBadge.classList.remove("is-visible");
    void elements.comboBadge.offsetWidth;
    elements.comboBadge.classList.add("is-visible");
  }

  function renderGame() {
    if (!game) {
      return;
    }
    renderBoard();
    renderTray();
    updateHud();
    updatePowerBar();
  }

  function renderBoard() {
    const boardTiles = game.tiles.filter((tile) => tile.status === "board");
    game.tiles.forEach((tile) => {
      if (!tile.element) {
        return;
      }
      const isBoardTile = tile.status === "board";
      tile.element.hidden = !isBoardTile;
      if (!isBoardTile) {
        return;
      }
      tile.element.style.left = `${tile.x}px`;
      tile.element.style.top = `${tile.y}px`;
      tile.element.style.setProperty("--z", String(100 + tile.z * 100));
      const covered =
        tile.status !== "board" ||
        boardTiles.some(
          (other) =>
            other.id !== tile.id &&
            other.z > tile.z &&
            boxesOverlap(tile, other),
        );
      tile.element.classList.toggle("is-covered", covered);
      tile.element.classList.remove("is-taken", "is-removing", "is-denied");
      tile.element.setAttribute("aria-disabled", covered ? "true" : "false");
    });
  }

  function renderTray() {
    elements.tray.replaceChildren();
    for (let slotIndex = 0; slotIndex < TRAY_SIZE; slotIndex += 1) {
      const slot = document.createElement("div");
      slot.className = "tray-slot";
      const tileId = game.tray[slotIndex];
      if (tileId) {
        const tile = game.tiles.find((candidate) => candidate.id === tileId);
        const character = tile ? getCharacter(tile.typeId) : null;
        if (character) {
          const tileElement = document.createElement("div");
          tileElement.className = "tray-tile";
          tileElement.style.background = character.accent;
          tileElement.innerHTML = `<img src="${character.image}" alt="${character.name}">`;
          slot.append(tileElement);
        }
      }
      elements.tray.append(slot);
    }
  }

  function updateHud() {
    const removed = game.tiles.filter((tile) => tile.status === "removed").length;
    const progress = game.tiles.length ? (removed / game.tiles.length) * 100 : 0;
    elements.scoreValue.textContent = String(game.score);
    elements.roundProgressBar.style.width = `${progress}%`;
  }

  function updatePowerBar() {
    const controls = [
      [elements.undoButton, elements.undoCount, game.powers.undo],
      [elements.shuffleButton, elements.shuffleCount, game.powers.shuffle],
      [elements.returnButton, elements.returnCount, game.powers.returnThree],
      [elements.hintButton, elements.hintCount, game.powers.hint],
    ];
    controls.forEach(([button, counter, value]) => {
      counter.textContent = String(value);
      button.disabled = value <= 0 || game.over;
    });
  }

  function undoMove() {
    if (!game || game.over || actionLock || game.powers.undo <= 0 || game.history.length === 0) {
      showToast("现在没有可以撤回的步骤");
      return;
    }
    const snapshot = game.history.pop();
    restoreSnapshot(snapshot);
    game.powers.undo -= 1;
    audio.play("power");
    renderGame();
  }

  function tryAssignBoardTypes(deficits) {
    const boardTiles = game.tiles.filter((tile) => tile.status === "board");
    const lookup = new Map(boardTiles.map((tile) => [tile.id, tile]));
    const remainingIds = new Set(boardTiles.map((tile) => tile.id));
    const groups = [];
    deficits.forEach((count, typeId) => {
      for (let index = 0; index < count; index += 1) {
        groups.push(typeId);
      }
    });
    const orderedGroups = [];
    shuffle([...new Set(groups)]).forEach((typeId) => {
      const count = groups.filter((candidate) => candidate === typeId).length;
      for (let index = 0; index < count; index += 1) {
        orderedGroups.push(typeId);
      }
    });

    boardTiles.forEach((tile) => {
      tile.typeId = null;
    });

    for (const typeId of orderedGroups) {
      const available = [];
      for (const tileId of remainingIds) {
        const tile = lookup.get(tileId);
        if (!isCoveredWithin(tile, remainingIds, lookup)) {
          available.push(tile);
        }
      }
      if (available.length === 0) {
        return false;
      }
      const selected = randomItem(available.slice(0, Math.min(5, available.length)));
      selected.typeId = typeId;
      remainingIds.delete(selected.id);
    }
    return remainingIds.size === 0;
  }

  function shuffleBoard() {
    if (!game || game.over || actionLock || game.powers.shuffle <= 0) {
      return;
    }
    const trayCounts = new Map();
    game.tray.forEach((tileId) => {
      const tile = game.tiles.find((candidate) => candidate.id === tileId);
      trayCounts.set(tile.typeId, (trayCounts.get(tile.typeId) || 0) + 1);
    });
    const deficits = new Map();
    game.typeDeck.forEach((typeId) => {
      const remaining = 3 - (trayCounts.get(typeId) || 0);
      if (remaining > 0) {
        deficits.set(typeId, remaining);
      }
    });

    pushHistory();
    for (let attempt = 0; attempt < 60; attempt += 1) {
      if (tryAssignBoardTypes(deficits)) {
        game.powers.shuffle -= 1;
        syncTileFaces();
        audio.play("power");
        renderGame();
        showToast("牌面已经重新排好");
        return;
      }
    }
    game.history.pop();
    showToast("这次洗牌没有成功，请再试一次");
  }

  function returnThreeTiles() {
    if (!game || game.over || actionLock || game.powers.returnThree <= 0) {
      return;
    }
    if (game.tray.length === 0) {
      showToast("卡槽里还没有牌");
      return;
    }

    pushHistory();
    const returnIds = game.tray.slice(0, 3);
    const maxZ = Math.max(...game.tiles.map((tile) => tile.z), 0);
    returnIds.forEach((tileId, index) => {
      const tile = game.tiles.find((candidate) => candidate.id === tileId);
      if (!tile) {
        return;
      }
      tile.status = "board";
      tile.z = maxZ + index + 1;
    });
    game.tray = game.tray.filter((tileId) => !returnIds.includes(tileId));
    game.powers.returnThree -= 1;
    audio.play("power");
    vibrate(16);
    renderGame();
  }

  function showHint() {
    if (!game || game.over || actionLock || game.powers.hint <= 0) {
      return;
    }
    const trayCounts = new Map();
    game.tray.forEach((tileId) => {
      const tile = game.tiles.find((candidate) => candidate.id === tileId);
      trayCounts.set(tile.typeId, (trayCounts.get(tile.typeId) || 0) + 1);
    });

    const availableByType = new Map();
    game.tiles
      .filter((tile) => tile.status === "board" && !isCovered(tile.id))
      .forEach((tile) => {
        if (!availableByType.has(tile.typeId)) {
          availableByType.set(tile.typeId, []);
        }
        availableByType.get(tile.typeId).push(tile);
      });

    for (const [typeId, available] of availableByType.entries()) {
      const needed = 3 - (trayCounts.get(typeId) || 0);
      if (needed > 0 && available.length >= needed) {
        available.slice(0, needed).forEach((tile) => {
          tile.element.classList.remove("is-hint");
          void tile.element.offsetWidth;
          tile.element.classList.add("is-hint");
          window.setTimeout(() => tile.element?.classList.remove("is-hint"), 2100);
        });
        game.powers.hint -= 1;
        audio.play("power");
        updatePowerBar();
        showToast("绿色卡槽里已有相同角色吗？");
        return;
      }
    }
    showToast("先清掉最上层的牌，才会出现新组合");
  }

  function syncTileFaces() {
    game.tiles.forEach((tile) => {
      const character = getCharacter(tile.typeId);
      if (!character || !tile.element) {
        return;
      }
      tile.element.style.setProperty("--accent", character.accent);
      tile.element.setAttribute("aria-label", character.name);
      const image = tile.element.querySelector("img");
      if (image) {
        image.src = character.image;
      }
    });
  }

  function finishLevel(won) {
    if (!game || game.over) {
      return;
    }
    game.over = true;
    actionLock = false;
    updatePowerBar();
    audio.play(won ? "win" : "lose");
    vibrate(won ? [30, 40, 60] : [80, 50, 80]);

    if (won) {
      if (!profile.completed.includes(game.level.id)) {
        profile.completed.push(game.level.id);
      }
      profile.unlocked = Math.max(
        profile.unlocked,
        Math.min(DATA.levels.length, game.level.id + 1),
      );
      profile.scores[game.level.id] = Math.max(
        profile.scores[game.level.id] || 0,
        game.score,
      );
      saveProfile();
      renderLevels();
    }

    openResult(won);
  }

  function openResult(won) {
    lastResult = { won, levelId: game.level.id, score: game.score };
    elements.resultCharacter.src = won
      ? "assets/characters/nailong-cheer.png"
      : "assets/characters/nailong-cool.png";
    elements.resultKicker.textContent = won ? "挑战完成" : "卡槽满啦";
    elements.resultTitle.textContent = won ? "顺利通关" : "再试一次";
    elements.resultScoreValue.textContent = String(game.score);

    const hasNext = won && game.level.id < DATA.levels.length;
    elements.resultPrimaryButton.textContent = won
      ? hasNext
        ? "下一关"
        : "返回关卡"
      : "再来一次";
    elements.resultSecondaryButton.textContent = won ? "再玩一次" : "返回关卡";
    openModal("result");
  }

  function openModal(name) {
    elements.modalLayer.hidden = false;
    document.querySelectorAll("[data-modal]").forEach((panel) => {
      panel.hidden = panel.dataset.modal !== name;
    });
    if (name === "ranking") {
      renderRanking();
    }
    if (name === "settings") {
      elements.soundToggle.checked = profile.settings.sound;
      elements.hapticsToggle.checked = profile.settings.haptics;
    }
    if (name === "dressup") {
      document.querySelectorAll("[data-theme-choice]").forEach((button) => {
        button.classList.toggle("is-active", button.dataset.themeChoice === profile.theme);
      });
    }
  }

  function closeModal() {
    elements.modalLayer.hidden = true;
    document.querySelectorAll("[data-modal]").forEach((panel) => {
      panel.hidden = true;
    });
  }

  function renderRanking() {
    const scores = Object.entries(profile.scores)
      .map(([levelId, score]) => ({
        levelId: Number(levelId),
        score: Number(score),
        level: getLevel(levelId),
      }))
      .filter((entry) => entry.level)
      .sort((first, second) => second.score - first.score)
      .slice(0, 8);

    elements.rankingList.replaceChildren();
    if (scores.length === 0) {
      const empty = document.createElement("p");
      empty.className = "empty-ranking";
      empty.textContent = "还没有通关记录，先去叠一局吧。";
      elements.rankingList.append(empty);
      return;
    }

    scores.forEach((entry, index) => {
      const row = document.createElement("div");
      row.className = "ranking-row";
      row.innerHTML = `
        <span class="ranking-row__place">${index + 1}</span>
        <div>
          <strong>第 ${entry.levelId} 关 · ${entry.level.name}</strong>
          <small>本机最高分</small>
        </div>
        <b>${entry.score}</b>
      `;
      elements.rankingList.append(row);
    });
  }

  function handleResultPrimary() {
    if (!lastResult) {
      return;
    }
    if (lastResult.won) {
      const nextLevel = lastResult.levelId + 1;
      if (nextLevel <= DATA.levels.length) {
        closeModal();
        startLevel(nextLevel);
      } else {
        closeModal();
        renderLevels();
        showScreen("levels");
      }
      return;
    }
    const restartLevel = lastResult.levelId;
    closeModal();
    startLevel(restartLevel);
  }

  function handleResultSecondary() {
    if (!lastResult) {
      return;
    }
    if (lastResult.won) {
      const replayLevel = lastResult.levelId;
      closeModal();
      startLevel(replayLevel);
      return;
    }
    closeModal();
    renderLevels();
    showScreen("levels");
  }

  function bindEvents() {
    elements.startButton.addEventListener("click", () => {
      renderLevels();
      showScreen("levels");
    });
    elements.rankingButton.addEventListener("click", () => openModal("ranking"));
    elements.settingsButton.addEventListener("click", () => openModal("settings"));
    elements.levelsSettingsButton.addEventListener("click", () => openModal("settings"));
    elements.dressupButton.addEventListener("click", () => openModal("dressup"));

    elements.levelsBackButton.addEventListener("click", () => showScreen("menu"));
    elements.gameBackButton.addEventListener("click", () => {
      if (game && !game.over && game.moveCount > 0) {
        const shouldLeave = window.confirm("当前进度不会保存，确定返回关卡地图吗？");
        if (!shouldLeave) {
          return;
        }
      }
      game = null;
      renderLevels();
      showScreen("levels");
    });

    elements.undoButton.addEventListener("click", undoMove);
    elements.shuffleButton.addEventListener("click", shuffleBoard);
    elements.returnButton.addEventListener("click", returnThreeTiles);
    elements.hintButton.addEventListener("click", showHint);

    elements.resultPrimaryButton.addEventListener("click", handleResultPrimary);
    elements.resultSecondaryButton.addEventListener("click", handleResultSecondary);

    elements.modalLayer.addEventListener("click", (event) => {
      if (event.target === elements.modalLayer && !elements.resultModal.hidden) {
        return;
      }
      if (event.target === elements.modalLayer) {
        closeModal();
      }
    });
    document.querySelectorAll(".modal-close").forEach((button) => {
      button.addEventListener("click", closeModal);
    });

    elements.soundToggle.addEventListener("change", () => {
      profile.settings.sound = elements.soundToggle.checked;
      saveProfile();
    });
    elements.hapticsToggle.addEventListener("change", () => {
      profile.settings.haptics = elements.hapticsToggle.checked;
      saveProfile();
    });
    elements.resetProgressButton.addEventListener("click", () => {
      const confirmed = window.confirm("确定清空所有通关记录和本机分数吗？");
      if (!confirmed) {
        return;
      }
      try {
        localStorage.removeItem(STORAGE_KEY);
      } catch {
        // Ignore unavailable local storage.
      }
      profile = loadProfile();
      applyTheme(profile.theme);
      renderLevels();
      closeModal();
      showToast("记录已经清空");
    });

    document.querySelectorAll("[data-theme-choice]").forEach((button) => {
      button.addEventListener("click", () => {
        applyTheme(button.dataset.themeChoice);
        showToast("舞台已经换装");
      });
    });

    window.addEventListener("resize", fitBoard);
    if (window.ResizeObserver) {
      const observer = new ResizeObserver(fitBoard);
      observer.observe(elements.boardWrap);
    }
    document.addEventListener("visibilitychange", () => {
      if (document.hidden && game && !game.over) {
        actionLock = false;
      }
    });
  }

  async function boot() {
    applyTheme(profile.theme);
    bindEvents();
    renderLevels();

    const startedAt = performance.now();
    let visualProgress = 0;
    const animateProgress = () => {
      const target = Math.max(visualProgress, 0.08);
      visualProgress += (target - visualProgress) * 0.18;
      const percent = Math.min(92, Math.round(visualProgress * 100));
      elements.loadingBar.style.width = `${percent}%`;
      elements.loadingPercent.textContent = `${percent}%`;
    };
    const interval = window.setInterval(animateProgress, 40);

    await preloadAssets((progress) => {
      visualProgress = Math.max(visualProgress, progress * 0.92);
    });
    await sleep(Math.max(0, 1350 - (performance.now() - startedAt)));
    window.clearInterval(interval);
    elements.loadingBar.style.width = "100%";
    elements.loadingPercent.textContent = "100%";
    await sleep(260);
    showScreen("menu");
  }

  boot().catch((error) => {
    console.error(error);
    elements.loadingPercent.textContent = "加载失败";
    showToast("资源加载失败，请检查文件夹是否完整", 5000);
  });
})();
