# 奶龙消消乐

一个纯 HTML、CSS、JavaScript 实现的叠叠乐三张消除小游戏。角色牌使用奶龙、奶娃图片；相同角色使用同一张图，三张相同角色进入底部卡槽后会自动消除。

## 软件运行

直接双击根目录中的 `奶龙消消乐.exe`。启动器会以独立桌面窗口打开游戏，不显示浏览器地址栏；游戏记录保存在同目录的 `.profile` 文件夹中。

软件使用系统自带或已安装的 Microsoft Edge / Google Chrome 作为显示引擎，因此不需要下载额外运行库。

## 网页方式运行

双击 `index.html` 即可游玩。若浏览器限制本地文件存储，可在本文件夹运行任意静态服务器，例如：

```powershell
python -m http.server 8765
```

然后访问 `http://127.0.0.1:8765/`。

## 玩法

- 只能点击没有被上层卡牌遮住的牌。
- 卡槽有 7 个位置，放入相同角色的 3 张牌会自动消除。
- 卡槽放满且没有形成三张消除时失败。
- 每关提供撤回、洗牌、退三张和提示道具。
- 通关记录和本地榜保存在浏览器 `localStorage` 中。

## 文件结构

```text
奶龙消消乐/
├─ 奶龙消消乐.exe         可双击运行的桌面启动程序
├─ index.html
├─ manifest.webmanifest
├─ README.md
├─ css/
│  └─ style.css
├─ data/
│  ├─ levels.js            游戏运行时读取的关卡数据
│  ├─ levels.json          同一份数据的 JSON 版本
│  └─ sources.json         图片来源与本地处理说明
├─ js/
│  └─ game.js
├─ assets/
│  └─ characters/          透明角色 PNG 与原始参考图
├─ launcher/
│  ├─ AppLauncher.cs       桌面启动器源码
│  ├─ app.ico              软件图标
│  ├─ build-launcher.ps1   重新编译 exe
│  └─ make_icon.py         重新生成图标
└─ tools/
   └─ prepare_assets.py    图片去白底、裁切和统一尺寸脚本
```

重新生成 Windows 启动程序：

```powershell
powershell -ExecutionPolicy Bypass -File .\launcher\build-launcher.ps1
```

## 素材说明

角色图片根据用户提供的参考图和网络搜索图筛选，然后在本地去除背景、统一裁切为 `512x512` 透明 PNG。项目仅用于本地学习和演示，不包含原参考游戏的代码或服务器接口。
