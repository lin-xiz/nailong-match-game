window.GAME_DATA = {
  version: 1,
  board: {
    width: 700,
    height: 710,
    tileSize: 84
  },
  traySize: 7,
  characters: [
    { id: "nailong-wave", name: "奶龙招手", image: "assets/characters/nailong-wave.png", accent: "#f7c948" },
    { id: "nailong-cheer", name: "奶龙欢呼", image: "assets/characters/nailong-cheer.png", accent: "#ffb648" },
    { id: "nailong-magnifier", name: "奶龙侦探", image: "assets/characters/nailong-magnifier.png", accent: "#ff9f43" },
    { id: "nailong-cool", name: "酷奶龙", image: "assets/characters/nailong-cool.png", accent: "#ff6f91" },
    { id: "naiwa-shush", name: "奶娃噤声", image: "assets/characters/naiwa-shush.png", accent: "#f7d154" },
    { id: "naiwa-peace", name: "奶娃比耶", image: "assets/characters/naiwa-peace.png", accent: "#f4b942" },
    { id: "naiwa-side", name: "奶娃侧身", image: "assets/characters/naiwa-side.png", accent: "#f08a3c" },
    { id: "naiwa-stand", name: "奶娃站好", image: "assets/characters/naiwa-stand.png", accent: "#e8aa36" }
  ],
  levels: [
    {
      id: 1,
      name: "奶龙热身",
      subtitle: "先来一小堆",
      groups: 10,
      layout: { rows: 4, cols: 4, layers: 3, pattern: "diamond" },
      undo: 3,
      shuffle: 2,
      returnThree: 1
    },
    {
      id: 2,
      name: "奶娃登场",
      subtitle: "叠叠乐来啦",
      groups: 12,
      layout: { rows: 5, cols: 4, layers: 3, pattern: "diamond" },
      undo: 3,
      shuffle: 2,
      returnThree: 1
    },
    {
      id: 3,
      name: "篮筐挑战",
      subtitle: "看准再下手",
      groups: 14,
      layout: { rows: 5, cols: 5, layers: 3, pattern: "diamond" },
      undo: 3,
      shuffle: 2,
      returnThree: 1
    },
    {
      id: 4,
      name: "欢乐舞台",
      subtitle: "层数开始变多",
      groups: 16,
      layout: { rows: 6, cols: 5, layers: 4, pattern: "diamond" },
      undo: 2,
      shuffle: 2,
      returnThree: 1
    },
    {
      id: 5,
      name: "奶龙派对",
      subtitle: "小心卡槽",
      groups: 18,
      layout: { rows: 6, cols: 6, layers: 4, pattern: "diamond" },
      undo: 2,
      shuffle: 2,
      returnThree: 1
    },
    {
      id: 6,
      name: "奶娃摇摆",
      subtitle: "高塔叠起来",
      groups: 21,
      layout: { rows: 7, cols: 6, layers: 4, pattern: "diamond" },
      undo: 2,
      shuffle: 1,
      returnThree: 1
    },
    {
      id: 7,
      name: "全国巡演",
      subtitle: "真正的高手关",
      groups: 24,
      layout: { rows: 7, cols: 7, layers: 4, pattern: "diamond" },
      undo: 1,
      shuffle: 1,
      returnThree: 1
    },
    {
      id: 8,
      name: "终极合唱",
      subtitle: "把奶龙带回家",
      groups: 28,
      layout: { rows: 8, cols: 7, layers: 4, pattern: "diamond" },
      undo: 1,
      shuffle: 1,
      returnThree: 1
    }
  ]
};
