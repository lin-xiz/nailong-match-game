const CACHE_NAME = "nailong-match-v1";
const CORE_ASSETS = [
  "./",
  "./index.html",
  "./manifest.webmanifest",
  "./css/style.css",
  "./data/levels.js",
  "./js/game.js",
  "./assets/icons/icon-192.png",
  "./assets/icons/icon-512.png",
  "./assets/characters/nailong-wave.png",
  "./assets/characters/nailong-cheer.png",
  "./assets/characters/nailong-magnifier.png",
  "./assets/characters/nailong-cool.png",
  "./assets/characters/nailong-hero.png",
  "./assets/characters/naiwa-shush.png",
  "./assets/characters/naiwa-peace.png",
  "./assets/characters/naiwa-side.png",
  "./assets/characters/naiwa-stand.png"
];

self.addEventListener("install", (event) => {
  event.waitUntil(
    caches
      .open(CACHE_NAME)
      .then((cache) => cache.addAll(CORE_ASSETS))
      .then(() => self.skipWaiting())
  );
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches
      .keys()
      .then((keys) =>
        Promise.all(
          keys.filter((key) => key !== CACHE_NAME).map((key) => caches.delete(key))
        )
      )
      .then(() => self.clients.claim())
  );
});

self.addEventListener("fetch", (event) => {
  if (event.request.method !== "GET") {
    return;
  }

  event.respondWith(
    caches.match(event.request).then((cachedResponse) => {
      if (cachedResponse) {
        return cachedResponse;
      }
      return fetch(event.request)
        .then((networkResponse) => {
          if (
            networkResponse &&
            networkResponse.status === 200 &&
            new URL(event.request.url).origin === self.location.origin
          ) {
            const responseCopy = networkResponse.clone();
            caches.open(CACHE_NAME).then((cache) => cache.put(event.request, responseCopy));
          }
          return networkResponse;
        })
        .catch(() => caches.match("./index.html"));
    })
  );
});
